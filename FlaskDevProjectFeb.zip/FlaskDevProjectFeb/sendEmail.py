import smtplib
import random

def password_data():
    with open('file.txt') as f:
        data = f.read()
    return data

def generateOTP():
    return random.randrange(1000, 9999)

def send_email(password, to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo() # Hello / EHLO
    server.starttls()
    server.login("jayakumarsanthosam@gmail.com", password)
    server.sendmail("jayakumarsanthosam@gmail.com", to, content)


if __name__ == "__main__":
    pwd = password_data()
    to = input("Enter the email of recipent:\n")
    content = str(generateOTP())
    send_email(pwd, to, content)
    print("msg sent")
    user_input = input("Enter the OTP: ")
    if user_input == content:
        print("Access Granted")
    else:
        print("Access Denied!!!!!!!!!")
