
from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def demo():
    if (True):
        name = "Sarath"
    else:
        name = "Gopinath"
    return render_template("jinja2.html", name = name)


@app.route('/forloop')
def demoLoops():
    name = ['Gopi', 'Babu', 'sarath']
    return render_template("jinja2.html", name = name)


if __name__ == "__main__":
    app.run(debug=True, port=8991)
