# Scenario 01: for Installation and starts the Server
# pip install flask

from flask import Flask

#Create Object
app = Flask(__name__)


# Run the Server
if __name__ == "__main__":
    app.run(debug=True)