# Scenario 03: for Variable
import os

from flask import Flask, render_template, request
from dataBase.TestData import Test_Data
from dataBase.DataBase import Data_Base

app_root = os.path.dirname(os.path.abspath(__file__))

#Create Object
app = Flask(__name__)


@app.route('/', methods = ['POST', 'GET'])
def login_page():
    alert=""
    if request.method == "POST":
        uName = request.form.get('USERNAME')
        pwd = request.form.get('PASSWORD')
        print(uName, pwd)
        # fetch the data from DataBase
        if uName == 'admin' and pwd == 'password':
            return render_template('homepage.html')
        else:
            alert = "invalid Credentials"
            return render_template('loginpage.html', alert = alert)
    return render_template('loginpage.html', alert = alert)


# @app.route('/<string:name>')          #<string:name>, <int:name>, <path:name>
def home_page(name):
    return f"Welcome {name}, You are in HomePage"


@app.route('/registration', methods=["GET", "POST"])
def registration():
    if request.method == "POST":
        fname = request.form.get("firstName")
        lname = request.form.get("lastName")
        email = request.form.get("email")
        pwd = request.form.get("password")
        print(fname, lname, email, pwd)
        data = Test_Data(fName=fname, lName=lname, email=email, pwd=pwd)
        con = db.get_connection()
        db.create_table(con)
        db.insert_record(con, data)
        db.close_Connection(con)
    return render_template("registration.html")

@app.route('/upload', methods = ["GET", "POST"])
def upload():
    if request.method == "POST":
        target_location = os.path.join(app_root, 'static/images/')
        if not os.path.isdir(target_location):
            os.mkdir(target_location)

        # print("fileName: ", request.files.getlist('file'))
        for f in request.files.getlist('file'):
            print("file name: ", f.filename)

        for file in request.files.getlist("file"):
            filename = file.filename
            print(filename)
            destination = "/".join([target_location, filename])
            print(destination)
            file.save(destination)
        return render_template("upload.html")
    return render_template("upload.html")

# Run the Server
if __name__ == "__main__":
    db = Data_Base('dataBase/datatoserver.db', 'sample')
    app.run(debug=True, port=5012)