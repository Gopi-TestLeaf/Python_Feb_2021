# Scenario 03: for Variable

from flask import Flask, render_template, request

#Create Object
app = Flask(__name__)


@app.route('/', methods = ['POST', 'GET'])
def login_page():
    alert=""
    if request.method == "POST":
        uName = request.form.get('USERNAME')
        pwd = request.form.get('PASSWORD')
        print(uName, pwd)
        # fetch the data from DataBase
        if uName == 'admin' and pwd == 'password':
            return render_template('homepage.html')
        else:
            alert = "invalid Credentials"
            return render_template('loginpage.html', alert = alert)
    return render_template('loginpage.html', alert = alert)


# @app.route('/<string:name>')          #<string:name>, <int:name>, <path:name>
def home_page(name):
    return f"Welcome {name}, You are in HomePage"


@app.route('/registration')
def registration():
    return "Registration - SignUp"


# Run the Server
if __name__ == "__main__":
    app.run(debug=True, port=5010)