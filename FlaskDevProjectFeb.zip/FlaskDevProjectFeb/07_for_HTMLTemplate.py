# Scenario 03: for Variable

from flask import Flask, render_template

#Create Object
app = Flask(__name__)


@app.route('/', methods = ['POST', 'GET'])
def login_page():
    return render_template('loginpage.html')


# @app.route('/<string:name>')          #<string:name>, <int:name>, <path:name>
def home_page(name):
    return f"Welcome {name}, You are in HomePage"


@app.route('/registration')
def registration():
    return "Registration - SignUp"


# Run the Server
if __name__ == "__main__":
    app.run(debug=True, port=5005)