# Scenario 02: for Route

from flask import Flask

#Create Object
app = Flask(__name__)


@app.route('/')
def login_page():
    return "Hello Everyone, We are develping API using Flask"

@app.route('/home')
def home_page():
    return "Welcome Gopi, You are in HomePage"


# Run the Server
if __name__ == "__main__":
    app.run(debug=True, port=5001)