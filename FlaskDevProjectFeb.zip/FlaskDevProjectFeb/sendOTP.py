import os

app_root = os.path.dirname(os.path.abspath(__file__)) # Getting file dir path
print(app_root)