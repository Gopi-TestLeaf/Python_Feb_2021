# Scenario 03: for Variable

from flask import Flask

#Create Object
app = Flask(__name__)


@app.route('/')
def login_page():
    return "Hello Everyone, We are develping API using Flask"

@app.route('/<name>')
def home_page(name):
    return f"Welcome {name}, You are in HomePage"


# Run the Server
if __name__ == "__main__":
    app.run(debug=True, port=5002)